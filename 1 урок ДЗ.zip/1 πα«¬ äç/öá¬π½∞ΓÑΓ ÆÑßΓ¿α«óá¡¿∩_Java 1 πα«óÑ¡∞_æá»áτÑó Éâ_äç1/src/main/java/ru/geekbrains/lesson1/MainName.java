package ru.geekbrains.lesson1;

class MainApp {
     public static void main(String[] args) {
        System.out.println("Hello, World!");
    }

}

class MainCifry {
    public static void main(String[] args) {
        byte a;
        a = 120;

        short b;
        b = 12442;

        int c = 1000;
        long d = 200000L;
        float e = 12.23f;
        double f = -123.123;

        char x, y;
        x = 'a';
        y = 2242;

        boolean o = false;

        System.out.println(a);
        System.out.println(b);
        System.out.println(c);
        System.out.println(d);
        System.out.println(e);
        System.out.println(f);
        System.out.println(o);
        System.out.println(x + y);
    }

}

class MainCifry2 {
    public static void main(String[] args) {

        float a = 12.20f;
        float b = 12.21f;
        float c = 12.22f;
        float d = 12.23f;

        float z =  a * (b + (c / d));

        System.out.println(z);
    }

}


class MainCifry3 {
    public static void main(String[] args) {

        int a = 7, b = 7;

        int c = a + b;

        if (c > 10 && c < 20) {
            System.out.println("true");
        } else {
            System.out.println("false");
        };

    }

}

class MainCifry4 {
    public static void main(String[] args) {

        int  c = 0;

        if (c >= 0) {
            System.out.println("с не отрицательно");
        } ;

        if(c < 0) {
            System.out.println("c отрицательно");
        } ;



    }

}


class MainCifry5 {
    public static void main(String[] args) {

        int  c = 0;

        if(c <= 0) {
            System.out.println("true");
        } else {
            System.out.println("false");
        };


    }

}



public class MainName {
    public static void main(String[] args) {
        Name1 ("Роман");
    }

    static void Name1(String name) {
        System.out.println("Привет, " + name + "!");
    }

}

